import numpy as np

SQRT_PI = np.sqrt(np.pi)

EPSILON = 1e-50

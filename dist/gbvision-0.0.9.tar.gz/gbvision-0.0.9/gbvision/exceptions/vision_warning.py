class VisionWarning(Warning):
    """
    generic vision warning
    """
    pass

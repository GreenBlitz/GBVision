
class AbstractMethodCallingException(Exception):
    """
    this is raised when the program attempted to call an abstract method
    """
    pass

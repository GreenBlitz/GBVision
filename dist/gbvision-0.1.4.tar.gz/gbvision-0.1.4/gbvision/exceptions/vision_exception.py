
class VisionException(Exception):
    """
    generic vision exception
    """
    pass

# GBVision
A Python Vision Library for object tracking in the 3D physical space

# Installation

`pip install gbvision`
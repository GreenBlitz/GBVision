VIDEO_FILE_TYPE = {
    '.AVI': 'XVID',
    '.MP4': 'MP4V',
    '.MJPEG': 'MJPG'
}
